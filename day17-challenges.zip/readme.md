# 피그마 링크
https://www.figma.com/file/nDtK7SzHIXhbA9eWDuMFUy/COFFEE/duplicate

# 텍스트 
```
MugApp

Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.

LOCATION
SHARE

All About Coffee
VIEW ALL

Reviews
VIEW ALL

Lorem ipsum dolor dolor sit amet, consectetuer adipiscing dolor sit amet, consectetuer adipiscing sdolor sit amet, consectetuer adipiscing dolor sit amet, consectetuer adipiscing it amet

Glenn Lee

Lorem ipsum dolor dolor sit amet, consectetuer adipiscing dolor sit amet, consectetuer adipiscing sdolor sit amet, consectetuer adipiscing dolor sit amet, consectetuer adipiscing it amet

Mike

Lorem ipsum dolor dolor sit amet, consectetuer adipiscing dolor sit amet, consectetuer adipiscing sdolor sit amet, consectetuer adipiscing dolor sit amet, consectetuer adipiscing it amet

Liam
```

